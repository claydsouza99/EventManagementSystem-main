import React from "react";

const PageNotFound = () => {
  return (
    <div className="position-absolute top-50 start-50 translate-middle display-1 text-white">
            Page Not Found
    </div>
  );
};

export default PageNotFound;
